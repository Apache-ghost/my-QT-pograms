#include <iostream>

using namespace std;

int main() {
    int num1, num2;

    // Prompt the user to enter the first number
    cout << "Enter the first number: ";
    cin >> num1;

    // Prompt the user to enter the second number
    cout << "Enter the second number: ";
    cin >> num2;

    // Display the original order
    cout << "Original order: " << num1 << " " << num2 << endl;

    // Swap the numbers
    int temp = num1;
    num1 = num2;
    num2 = temp;

    // Display the swapped order
    cout << "Swapped order: " << num1 << " " << num2 << endl;

    return 0;
}
