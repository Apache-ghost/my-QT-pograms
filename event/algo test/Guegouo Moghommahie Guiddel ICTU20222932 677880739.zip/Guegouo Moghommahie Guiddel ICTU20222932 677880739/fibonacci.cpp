#include <iostream>

using namespace std;

int main() {
    int n = 100;
    int fib[n];

    // Initialize the first two terms
    fib[0] = 1;
    fib[1] = 1;

    // Compute and store the remaining terms
    for (int i = 2; i < n; i++) {
        fib[i] = fib[i-1] + fib[i-2];
    }

    // Display the terms
    for (int i = 0; i < n; i++) {
        cout << fib[i] << " ";
    }
    cout << endl;

    return 0;
}
