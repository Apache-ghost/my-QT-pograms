#include <iostream>

using namespace std;

int main() {
    // Get the size of the square from the user
    int size;
    cout << "Enter the size of the square: ";
    cin >> size;

    // Print the top border
    for (int i = 0; i < size; i++) {
        cout << "x ";
    }
    cout << endl;

    // Print the sides of the square
    for (int i = 0; i < size - 2; i++) {
        cout << "x ";
        for (int j = 0; j < size - 2; j++) {
            cout << ". ";
        }
        cout << "x" << endl;
    }

    // Print the bottom border
    for (int i = 0; i < size; i++) {
        cout << "x ";
    }
    cout << endl;

    return 0;
}