#include <iostream>

using namespace std;

int main() {
    const int N = 10; // The number of rows
    for (int i = 0; i < N; i++) {
        for (int j = 0; j <= i; j++) {
            cout << j << " ";
        }
        cout << endl;
    }
    return 0;
}