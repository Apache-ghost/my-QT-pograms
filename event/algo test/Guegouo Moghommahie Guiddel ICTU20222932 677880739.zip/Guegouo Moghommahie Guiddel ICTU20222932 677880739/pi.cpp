#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() {
    int n = 1000000; // number of points to generate
    double radius = 0.5; // radius of the disc
    double x, y; // coordinates of the points
    int count = 0; // number of points in the disc

    // Set the random seed based on the current time
    srand(time(NULL));

    // Generate n random points in the square [-1, 1] x [-1, 1]
    for (int i = 0; i < n; i++) {
        x = (double)rand() / RAND_MAX * 2 - 1;
        y = (double)rand() / RAND_MAX * 2 - 1;

        // Check if the point is inside the disc
        if (sqrt(x*x + y*y) <= radius) {
            count++;
        }
    }

    // Estimate PI as the ratio of the number of points in the disc to the total number of points,
    // multiplied by the area of the square, divided by the area of the disc.
    double pi = 4 * (double)count / n;

    // Print the estimate of PI
    cout << "Estimated value of PI: " << pi << endl;

    return 0;
}
